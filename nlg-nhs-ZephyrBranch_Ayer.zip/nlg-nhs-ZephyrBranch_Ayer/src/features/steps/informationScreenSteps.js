import {Then} from "@cucumber/cucumber";
import profilePage from "../pages/actions/profilePage";
import utility from "../../utilities/utility";
import wardScreenPage from "../pages/actions/wardScreenPage";
import settingsPage from "../pages/actions/settingsPage";
import informationScreenSettings from "../pages/actions/informationScreenSettings";
import roleSettingsPage from "../pages/actions/roleSettingsPage";

Then('user clicks on the sub-navigation in action menu {string}', {timeout: 60 * 1000},async function(label){
    await profilePage.clickProfileMenu(this.page,label);
});

Then('add patient {string} in the holding area', {timeout: 60 * 1000},async function(value){
    let patientIdentifierSearch = await utility.getJsonValue(value);
    await this.attach("Patient Identifier Search: "+patientIdentifierSearch, 'text/plain');
    await wardScreenPage.addPatientInHoldingArea(this.page, patientIdentifierSearch);
});

Then('verify plus button exists', {timeout: 60 * 1000},async function(){
  await settingsPage.verifyPlusButtonExists(this.page);
});

Then('verify back button exists', {timeout: 60 * 1000},async function(){
    await settingsPage.verifyBackButtonExists(this.page);
});

Then('verify each row has a right arrow icon and and ellipse present', {timeout: 60 * 1000},async function(){
    await informationScreenSettings.verifyEachRowContainsArrowIconAndEllipse(this.page);
});

Then('user inputs {string} with random value in information page',  {timeout: 60 * 1000},async function(label){
    let randomValue = await informationScreenSettings.inputRandomValueInline(this.page,label);
    await this.attach("Random Value Name: "+randomValue, 'text/plain');
});

Then('user clicks on the card {string}',  {timeout: 60 * 1000},async function(label){
    await informationScreenSettings.clickOnCard(this.page,label);
});

Then('user clicks on magnifying glass on the ward page',  {timeout: 60 * 1000},async function(){
    await informationScreenSettings.clickOnWardMagnifyingGlass(this.page);
});

Then('verify the mouse select has shifted to a for way icon',  {timeout: 60 * 1000},async function(){
    await informationScreenSettings.verifyForWayMouseIcon(this.page);
});

Then('save the translate option of the viewpoint',  {timeout: 60 * 1000},async function(){
    let offsetValue = await informationScreenSettings.saveTranslate(this.page);
    await this.attach("Offset Left: "+offsetValue, 'text/plain');
});

Then('we drag and drop from {string} to {string}',  {timeout: 360 * 1000},async function(source,destination){
    await informationScreenSettings.dragAndDropXpath(this.page,source,destination);
});

Then('compare the translate option of the viewpoint',  {timeout: 60 * 1000},async function(){
    let offsetValue = await informationScreenSettings.compareTranslate(this.page);
    await this.attach("New Offset Left: "+offsetValue, 'text/plain');
});