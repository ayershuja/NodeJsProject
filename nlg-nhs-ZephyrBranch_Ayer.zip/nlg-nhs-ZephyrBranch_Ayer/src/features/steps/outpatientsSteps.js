import {Given,Then} from "@cucumber/cucumber";
import outpatientsPage from "../pages/actions/outpatientsPage";


Then('verify column {string} of clinic name {string} contains value {string}', {timeout: 60 * 1000},async function(column,code,value) {

    await outpatientsPage.verifyTableColumns(this.page,column,code,value);
});
Then('user clicks on the meatball option in the patient list table', {timeout: 60 * 1000},async function() {

    await outpatientsPage.meatballOptions(this.page);
});
Then('verify appointment status is {string}', {timeout: 60 * 1000},async function(value) {

    await outpatientsPage.appointmentStatus(this.page,value);
});
Then('verify current date exists in parameter', {timeout: 60 * 1000},async function() {

    await outpatientsPage.verifyParamDate(this.page);
});
Then('verify header name contains {string}', {timeout: 60 * 1000},async function(value) {

    await outpatientsPage.verifyHeaderName(this.page,value);
});
Then('verify header code contains {string}', {timeout: 60 * 1000},async function(value) {

    await outpatientsPage.verifyHeaderCode(this.page,value);
});
Then('verify header speciality contains {string}', {timeout: 60 * 1000},async function(value) {

    await outpatientsPage.verifyHeaderSpeciality(this.page,value);
});
Then('verify header start contains {string}', {timeout: 60 * 1000},async function(value) {

    await outpatientsPage.verifyHeaderStart(this.page,value);
});
Then('verify header capacity contains {string}', {timeout: 60 * 1000},async function(value) {

    await outpatientsPage.verifyHeaderCapacity(this.page,value);
});
Then('verify header status contains {string}', {timeout: 60 * 1000},async function(value) {

    await outpatientsPage.verifyHeaderStatus(this.page,value);
});
