import input from "../../../utilities/input";
import patientLocators from "../../locators/patientValues.json";
import {expect} from "chai";

class PatientDocumentsPage {
    canvasElement=null;
    async verifyTool(page, toolName) {
        let toolXpath = "//div[contains(@id,'toolGroup') and contains(text(),'"+toolName+"')]";
        let nameOfTool = await input.getElementTextUsingXpath(page,toolXpath,"innerText");
        expect(nameOfTool).to.be.equal(toolName.toUpperCase());
    }

    async signDocument(page) {
        let canvasElement = await page.waitForXPath(patientLocators.patientDocuments.xpath.canvasStore,{visible:true});
        let boundingBox = canvasElement.boundingBox();
        // await canvasElement.click();
        this.canvasElement = await page.evaluate(el => {
            let context = el.getContext("2d");
            context.fillText("Hello World", 10, 50);
            el.click();
            return el.toDataURL();
        }, canvasElement);
        await page.waitForTimeout(5000);
        await page.mouse.move(boundingBox.x+1,boundingBox.y+1);
        await page.mouse.down();
        await page.mouse.move(boundingBox.x+100,boundingBox.y+100);
        await page.mouse.up();
    }

    async verifySignature(page) {
        let image = await page.waitForXPath(patientLocators.patientDocuments.xpath.signatureImage,{visible:true});
        let imageSrc = await (await image.getProperty("src")).jsonValue();
        await console.log("Before: "+this.canvasElement);
        await console.log("After: "+imageSrc);
        expect(imageSrc).to.equal(this.canvasElement);
    }
}

export default new PatientDocumentsPage()
