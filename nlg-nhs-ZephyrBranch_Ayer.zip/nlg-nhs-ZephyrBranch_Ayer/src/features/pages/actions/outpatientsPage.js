import click_utility from "../../../utilities/clicking";
import Input_utility from "../../../utilities/input";
import Input from "../../../utilities/input";
import {expect} from "chai";
import navBarLocator from "../../locators/navigationBar.json";
import input from "../../../utilities/input";
import navigationLocator from "../../locators/navigationBar.json";
import outPatientsClinics from "../../locators/outPatientsClinic.json";
import profileLocators from "../../locators/profilePage.json";

class outpatientsPage {

    async verifyTableColumns(page, column, code, value) {

        let xpath = "(//div[contains(@class,'data-set-row')]/div[contains(text(),\"" + code + "\")])[1]/following-sibling::div["+column+"]"
        let pageValue = await Input.getElementTextUsingXpath(page,xpath,"textContent");
        expect(value).to.be.equal(pageValue);
    }

    async meatballOptions(page) {

        await click_utility.clickElementByXpath(page,outPatientsClinics.xpath.meatballs);
    }

    async appointmentStatus(page,value) {

        let xpath = "//div[@class='container-column'][contains(.,'"+value+"')]";
        let Status = await Input.getElementTextUsingXpath(page,xpath,"textContent");
        expect(value).to.be.equal(Status);
    }

    async verifyParamDate(page) {

        let value = await input.getTextOfTheElements(page,outPatientsClinics.xpath.param_date);
        let currentDate = await this.todaysDate("dd-MMM-yyyy");
        let Date = value[0].replace(/\b0/g, '');

        console.log("***************************************************");
        console.log("value:" +value);
        console.log("currentDate: " +currentDate);
        console.log("Date: " +Date);
        console.log("***************************************************");

        expect(currentDate).to.be.equal(Date);

    }

    async todaysDate(format){
        // let format = "dd-MMM-YYYY HH:MM";
        const date = new Date();
        const map = {
            // mm: date.getMonth() + 1,
            MMM: date.toLocaleString('default', { month: 'short' }),
            dd: date.getDate(),
            // yy: date.getFullYear().toString().slice(-2),
            yyyy: date.getFullYear(),
            HH: ((date.getHours()<10?'0':'') + date.getHours()),
            MM: ((date.getMinutes()<10?'0':'') + date.getMinutes())
        }
        // console.log(ex);
        return format.replace(/MMM|dd|yyyy|HH|MM/gi, matched => map[matched]);
    }

    async verifyHeaderName(page,value) {

        let foundNameText = await Input.getElementTextUsingXpath(page, outPatientsClinics.xpath.header_Name, "innerText");
        expect(foundNameText).to.be.equal(value);
    }

    async verifyHeaderCode(page,value) {

        let xpath = "//span[@class='system-bar-extra-content-display'][contains(.,\"" + value + "\")]";
        let foundCodeText = await Input.getElementTextUsingXpath(page, xpath, "innerText");
        expect(foundCodeText).to.be.equal(value);
    }

    async verifyHeaderSpeciality(page,value) {

        let xpath = "//span[@class='system-bar-extra-content-display'][contains(.,\"" + value + "\")]";
        let foundSpecialityText = await Input.getElementTextUsingXpath(page, xpath, "innerText");
        expect(foundSpecialityText).to.be.equal(value);
    }

    async verifyHeaderStart(page,value) {

        let xpath = "//span[@class='system-bar-extra-content-display'][contains(.,\"" + value + "\")]";
        let foundStartText = await Input.getElementTextUsingXpath(page, xpath, "innerText");
        expect(foundStartText).to.be.equal(value);
    }

    async verifyHeaderCapacity(page,value) {

        let xpath = "//div[@class='color-green'][contains(.,\"" + value + "\")]";
        let foundCapacityText = await Input.getElementTextUsingXpath(page, xpath, "innerText");
        expect(foundCapacityText).to.be.equal(value);
    }

    async verifyHeaderStatus(page,value) {

        let foundStatusText = await Input.getElementTextUsingXpath(page, outPatientsClinics.xpath.header_Status, "innerText");
        expect(foundStatusText).to.be.equal(value);
    }

}

export default new outpatientsPage()