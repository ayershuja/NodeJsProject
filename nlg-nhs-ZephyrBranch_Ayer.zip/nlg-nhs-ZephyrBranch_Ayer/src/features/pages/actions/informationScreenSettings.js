import { expect } from "chai";
import click_utility from "../../../utilities/clicking";
import announcementPage from "./announcementPage";
import navigationPage from "./navigationBar";
import Input from "../../../utilities/input";
import documentSettingsPage from "./documentSettingsPage";
import accountSettingsPage from "./accountSettingsPage";
import Input_utility from "../../../utilities/input";
import informationScreenLocators from "../../locators/informationScreen.json";
import clicking from "../../../utilities/clicking";
import input from "../../../utilities/input";
import input_utility from "../../../utilities/input";

class InformationScreenSettings {

    randomValueGenerated;
    translate;

    async createIndicatorsIfNotExist(page, indicatorName, propertyName) {
        // await documentSettingsPage.clickOnTableFirstRow(page, indicatorName);
        // await announcementPage.waitForLoading(page);
        // await page.waitForTimeout(3000);
        let detailItemsXpath =
            "//div[contains(@class,'body')]//div[contains(@class,'cell')][contains(text(),'" +
            indicatorName +
            "')]";

        let elementValues = await Input.getTextOfTheElements(
            page,
            detailItemsXpath
        );
        console.log("fetched items : ");
        console.log(elementValues);
        console.log(elementValues.length);

        if (elementValues.length < 1) {
            await announcementPage.clickOnPlusIcon(page);
            await documentSettingsPage.inputValueInline(page, "Name", indicatorName);
            await navigationPage.clickOnPopupItem(page, "Property");
            await announcementPage.verifyPopUpLabel(page, "Property Search");
            await navigationPage.clickOnPopupItem(page, "Use Existing Property");
            await page.waitForTimeout(3000);
            await announcementPage.clickonCheckIcon(page);
            await page.waitForTimeout(10000);
            await announcementPage.verifyPopUpLabel(
                page,
                "Existing Property Search Results"
            );
            // await announcementPage.clickonCheckIcon(page);
            await announcementPage.waitForLoading(page);
            await accountSettingsPage.searchInFilter(page, propertyName);
            await navigationPage.clickOnPopupItem(page, propertyName);
            await page.waitForTimeout(3000);
            await announcementPage.clickonCheckIcon(page);
            await page.waitForTimeout(3000);
            await announcementPage.clickonCheckIcon(page);
            await announcementPage.verifyForm(page,"Success");
            await announcementPage.clickonCheckIcon(page);
            await announcementPage.clickonPopUpBackIcon(page);
        }

    }

    async addClinicalIndicatorIconIfNotExist(page,indicatorName, iconSetName, selectionValues, clinicalIndicators){

        let headerValueXpath =
            "//div[text()='"+indicatorName+"']//following-sibling::div[4]";
        let headerValue = await Input.getTextOfTheElements(
            page,
            headerValueXpath
        );
            if(headerValue==="Not Known"){
                let menuOption =
                    "(//div[contains(@class,'body')]//div[contains(@class,'cell')][translate(text(),'abcdefghijklmnopqrstuvwxyz','ABCDEFGHIJKLMNOPQRSTUVWXYZ')='" +
                    indicatorName.toUpperCase() +
                    "'])[1]";
                await clicking.clickElementByXpath(page, menuOption);
                await announcementPage.waitForLoading(page);
                await page.waitForTimeout(3000);
                await announcementPage.clickOnActionIconWithHeaderName(
                    page,
                    "Clinical Indicator Details"
                );
                await navigationPage.clickOnPopupItem(page, "Edit");
                await navigationPage.clickOnPopupItem(page, "Property Icons");
                await navigationPage.clickOnPopupItem(page, "Icon Set");
                await announcementPage.waitForLoading(page);
                await accountSettingsPage.searchInFilter(page, iconSetName);
                await navigationPage.clickOnPopupItem(page, iconSetName);
                await announcementPage.waitForLoading(page);

                const selectionValArray = selectionValues.split("|");
                const clinicalIndicatorArray = clinicalIndicators.split("|");
                for (let i = 0; i < selectionValArray.length; i++) {
                    await navigationPage.clickOnPopupItem(page, selectionValArray[i]);
                    await announcementPage.waitForLoading(page);
                    await accountSettingsPage.searchInFilter(page, clinicalIndicatorArray[i]);
                    await navigationPage.clickOnPopupItem(page, clinicalIndicatorArray[i]);
                    await announcementPage.waitForLoading(page);
                }

                await announcementPage.clickonCheckIcon(page);
                await announcementPage.clickonCheckIcon(page);
                await announcementPage.verifyForm(page,"Success");
                await announcementPage.clickonCheckIcon(page);
                await announcementPage.clickonPopUpBackIcon(page);
            }

    }

    async configGlobalIndicatorIfNotConfigured(page, globalIndicatorName, clinicalIndicatorName){
        await announcementPage.clickOnActionIconWithHeaderName(
            page,
            "Location List"
        );
        await announcementPage.waitForLoading(page);
        await navigationPage.clickOnPopupItem(page, "Configure Global Indicator Categories");

        let pageXpath =
            "//*[translate(text(),'abcdefghijklmnopqrstuvwxyz','ABCDEFGHIJKLMNOPQRSTUVWXYZ')='"+globalIndicatorName.toUpperCase()+"']/../..";
        console.log(pageXpath);
        let globalIndicationIsExist = false;
        try {
            await page.waitForXPath(pageXpath, { visible: true, timeout: 20000 });
            globalIndicationIsExist = true;
        } catch (e) {
            globalIndicationIsExist = false;
        }

        if(!globalIndicationIsExist) {
            await announcementPage.clickOnPlusIcon(page);
            await documentSettingsPage.inputValueInline(page, "Name", globalIndicatorName);
            await announcementPage.clickonCheckIcon(page);
            await announcementPage.waitForLoading(page);
            await announcementPage.clickonCheckIcon(page);
            await announcementPage.verifyForm(page,"Submission Successful");
            await announcementPage.clickonCheckIcon(page);
            await navigationPage.clickOnPopupItem(page, globalIndicatorName);
            await announcementPage.waitForLoading(page);
            await announcementPage.clickOnActionIconWithHeaderName(
                page,
                "Indicator Category Details"
            );
            await navigationPage.clickOnPopupItem(page, "Enable");
            await announcementPage.clickonCheckIcon(page);
            await announcementPage.verifyForm(page,"Successfully Enabled");
            await announcementPage.clickonCheckIcon(page);
            await announcementPage.clickonPopUpBackIcon(page);
        }
        if(globalIndicationIsExist) {
            await navigationPage.clickOnPopupItem(page, globalIndicatorName);
            await announcementPage.waitForLoading(page);
            await navigationPage.clickOnPopupItem(page, "Clinical Indicators");

            let clinicalXpath =
                "//*[translate(text(),'abcdefghijklmnopqrstuvwxyz','ABCDEFGHIJKLMNOPQRSTUVWXYZ')='" + clinicalIndicatorName.toUpperCase() + "']/../..";
            console.log(clinicalXpath);
            let clinicalIndicationIsExist = false;
            try {
                await page.waitForXPath(clinicalXpath, {visible: true, timeout: 20000});
                clinicalIndicationIsExist = true;
            } catch (e) {
                clinicalIndicationIsExist = false;
            }

            if (!clinicalIndicationIsExist) {
                await announcementPage.clickOnActionIconWithHeaderName(
                    page,
                    "Clinical Indicator List"
                );
                await navigationPage.clickOnPopupItem(page, "Add Clinical Indicator");
                await accountSettingsPage.searchInFilter(page, clinicalIndicatorName);
                await navigationPage.clickOnPopupItem(page, clinicalIndicatorName);
                await announcementPage.verifyForm(page, "Submission Successful");
                await announcementPage.clickonCheckIcon(page);
                await announcementPage.clickonPopUpBackIcon(page);
            }
            await announcementPage.clickonPopUpBackIcon(page);
        }
        await announcementPage.clickonPopUpBackIcon(page);
        await announcementPage.clickonPopUpBackIcon(page);
        await announcementPage.clickonPopUpBackIcon(page);
    }

    async verifyClinicalIndicatorPopover(page,bedNo, icon, indicatorName, propValue){
        let bedSlotIconXpath = "//div[contains(text(),'"+bedNo+"')]/../..//img[contains(@src,'"+icon+"')]";

        let iconEle = await page.waitForXPath(bedSlotIconXpath,{visible:true,timeout:20000});
        const className = await(await iconEle.getProperty('src')).jsonValue();
        expect(className.includes(icon)).to.be.true;
        await click_utility.hoverOverElementByXpath(page,bedSlotIconXpath);

        let foundClinicalIndicatorName = await Input_utility.getElementTextUsingXpath(page,informationScreenLocators.xpath.popoverClinicalIndicatorName,"innerText");
        let foundClinicalIndicatorValue = await Input_utility.getElementTextUsingXpath(page,informationScreenLocators.xpath.popoverClinicalIndicatorValue,"innerText");
        let foundClinicalIndicatorIcon = await Input_utility.getElementTextUsingXpath(page,informationScreenLocators.xpath.popoverClinicalIndicatorIcon,"src");

        await expect(foundClinicalIndicatorName.toUpperCase().trim()).to.be.equal(indicatorName.toUpperCase().trim());
        await expect(foundClinicalIndicatorValue.toUpperCase().trim()).to.be.equal(propValue.toUpperCase().trim());
        await expect(foundClinicalIndicatorIcon.toUpperCase().trim()).to.be.includes(icon.toUpperCase().trim());

    }

    async verifyEachRowContainsArrowIconAndEllipse(page) {
        let tableRows = await input.getTextOfTheElements(page,informationScreenLocators.xpath.tableRows);
        let index=0;
        for(let item in tableRows){
            index = parseInt(item)+1;
            console.log("Index: "+index);
            let arrowContainsXpath = "//div[@class='table-body']//div[contains(@class,'table-row')]["+index+"]//div[contains(@class,'meatballs table-cell')]";
            let ellipseContainsXpath = "//div[@class='table-body']//div[contains(@class,'table-row')]["+index+"]//div[contains(@class,'meatballs table-cell')]//div[contains(@class,'meatballs')]";
            let arrowElement = await page.waitForXPath(arrowContainsXpath);
            let ellipseElement = await page.waitForXPath(ellipseContainsXpath);
            if(arrowElement===null||ellipseElement===null){
                expect(true).to.be.false;
            }
        }
    }

    async inputRandomValueInline(page, label) {
        this.randomValueGenerated = Math.random().toString(36).substring(2,7);
        console.log(this.randomValueGenerated);
        let xpath = "//div[contains(@id,'appended-elements')]//div[text()='"+label+"']/ancestor::div[contains(@class,'container-column')]/following-sibling::div//input|//div[contains(@id,'appended-elements')]//div[text()='"+label+"']/following-sibling::div//input";
        await input_utility.removeTextByXpath(page,xpath);
        await input_utility.enterTextXpath(page,xpath,this.randomValueGenerated);
        return this.randomValueGenerated;
    }

    async clickOnCard(page, label) {
        let cardXpath = "//div[@class='main-text'][text()='"+label+"']|//div/span[text()='"+label+"']";
        await click_utility.clickElementByXpath(page,cardXpath);
        await page.waitForTimeout(2000);
    }

    async clickOnWardMagnifyingGlass(page) {
        await clicking.clickElementByXpath(page,informationScreenLocators.xpath.magnifyingGlass);
    }

    async verifyForWayMouseIcon(page) {
        await page.waitForXPath(informationScreenLocators.xpath.forWayIcon);
    }

    async saveTranslate(page) {
        let translateElement = await page.waitForXPath(informationScreenLocators.xpath.translateElement);
        let className = await (await translateElement.getProperty('offsetLeft')).jsonValue();
        console.log(className);
        this.translate=className;
        return className;
    }

    async dragAndDropXpath(page,source,destination) {
        let sourceXpath = "//div[contains(text(),'"+source+"')]"
        let destinationXpath = "//div[contains(text(),'"+destination+"')]"
        await clicking.dragAndDropXpath(page,sourceXpath,destinationXpath);
    }

    async compareTranslate(page) {
        let translateElement = await page.waitForXPath(informationScreenLocators.xpath.translateElement);
        let className = await (await translateElement.getProperty('offsetLeft')).jsonValue();
        console.log(className);
        expect(className).to.not.be.equal(this.translate);
        return className;
    }
}
export default new InformationScreenSettings();