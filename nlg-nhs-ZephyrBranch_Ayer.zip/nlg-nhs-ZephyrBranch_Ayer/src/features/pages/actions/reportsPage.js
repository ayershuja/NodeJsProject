class ReportSettingsPage {
    async reportsUnavailable(page) {

    }
}

export default new ReportSettingsPage()
