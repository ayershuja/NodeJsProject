Pre-Req:
1. Node.Js    

Node (version : v14.17.3 or above)  npm (version : 7.20.0 or above) must be installed

	
	confirm installation is successful by checking following commands:
	>> node --version
	>> npm --version

	
2. Install Libraries
	>> npm install or npm i
	
Run Scripts
1. Open command prompt and navigate to project directory like "C:\Kualitee-Automation"
== To run specific feature file with cucumber tag and mention the tag name in the package.json file under scripts section (cucumber-tag)
npm run test-tag
== To run e2e 
npm test
 